clc
clearvars
close all
global rbfscale rbf_type Npoly rbfpar do_scaling
global rbfw_type scaling_size
global X Xc Xeval h_y rcov
global h
a=0;bb=1;c=0;d=1;
h=0.05;
N = 1000;    % number of time steps 100 200 400 800 1600 3200 6400 12800
T_F =2;    % final time
dt = T_F / N;

s1 = 1;   % delay
m = round(s1/dt); % delay steps (integer)

%% partition of unity options
trial_func = 'Power';%  
switch trial_func
    case 'Power'
        rbf_type = 'Polyharmonic';
        rbfpar = 8;
        Npoly = 5; %ceil(rbfpar/2)
        do_scaling = 2;
end
rbfw_type = 'Wendland31';  %Wendland31 Wendland3
h_y = 4*h;
rcov =sqrt(2)*h_y ;
scaling_size = rcov;
[Xc,Xci,Xcb] = points_sq_unity(a,bb,c,d,h_y,'R');
dist_type = 'Uniform'; % Halton  Uniform
domain_type = 0;%0,7
Points = Omega(a,bb,c,d,h,dist_type,domain_type);
Xi = Points{1,1};
Xb = Points{2,1};
X=[Xi;Xb];
n=size(X,1);
Pointse = Omega(a,bb,c,d,h/sqrt(2),dist_type,domain_type);
Xei = Pointse{1,1};
Xeb = Pointse{2,1};
Xeval=[Xei;Xeb];
Aeval = PUmat('0',X,Xeval);
[Ai,delAi]= PUmat('L',X,Xi);
deldelAi = PUmat('L2',X,Xi);
Ab = PUmat('0',X,Xb);

gamma = 1/5;
delta1 = 1/2;
delta2 = 1;
delta3 = 2;
delta4 = 1;

% System matrix incorporating delay term u^n and Laplacian
A = [Ai - delta1 * dt * delAi + delta3 * dt * Ai; Ab];  % Dirichlet BC included

% LU decomposition for solving system fast
[L, U, Pp] = lu(A);
Inv_A = U \ (L \ (Pp * eye(n)));

% Initialize solution matrix (for n from -m to N, we need N+m+1 slots)
U1 = zeros(n, N + m + 1);  % U1(:, j) corresponds to time t = (j - m - 1) * dt

% مقداردهی اولیه برای زمان‌های t = -m*dt تا t = 0
for jj = -m:0
    U1(:, jj + m + 1) = [f(Xi, jj*dt); f(Xb, jj*dt)];
end

% Time stepping
for j = m + 2 : N + m + 1  % چون j - m باید ≥ 1 باشد
    % تأخیر: u^{n-m}
    if j - m <= 0
        delayed_u0 = [f(Xi, (j-1 - m)*dt); f(Xb, (j-1 - m)*dt)];
    else
        delayed_u0 = U1(:, j - m);
    end

    % تأخیر: u^{n-m-1}
    if j - m - 1 <= 0
        delayed_u1 = [f(Xi, (j - 2 - m)*dt); f(Xb, (j - 2 - m)*dt)];
    else
        delayed_u1 = U1(:, j - m - 1);
    end



    % Right-hand side construction
    RI = Ai * U1(:, j - 1) ...
         + gamma * Ai * (delayed_u0 - delayed_u1) ...
         + delta2 * dt * delAi * delayed_u0 ...
         - delta4 * dt * Ai * delayed_u0 ...
         + dt * g(Xi, (j - m - 1) * dt, s1);

    RB = f(Xb, (j - m - 1) * dt);  % Boundary condition at current time

    % Solve system
   % U1(:, j) = Inv_A * [RI; RB];
     U1(:, j) = U \ (L \ (Pp * [RI; RB]));
end

apf = U1(:, end);

% Exact solution at final time
Uex = f(X, T_F);

%twonorm_err = norm(apf - Uex, 2) 
maxerr = norm(apf - Uex, inf);

% Relative Errors
%rel_twonorm_err = norm(apf - Uex, 2) / norm(Uex, 2)

MethodType='Direct RBF-PUM';
fprintf('Step size (h): %.4f\n', h);
fprintf('Max error: %.4e\n', maxerr);
fprintf('Method Type: %s\n', MethodType);
fprintf('T_F = %.1f\n', T_F);

