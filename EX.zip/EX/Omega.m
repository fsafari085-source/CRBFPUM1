function Points = Omega(a,b,c,d,h,dist_type,domain_type)
switch nargin
    case 6
        domain_type = 'Uniform';
    case 5
        domain_type = '1';
        dist_type = 'Uniform';
end
switch domain_type
    case 0 % Rectangular domain with circular holes
    % پارامترهای شبکه مستطیلی
    yh = a+h:h:b-h;
    yv = c+h:h:d-h;
    n1 = size(yh, 2);
    n2 = size(yv, 2);

    % مرزهای چهار ضلع و گوشه‌ها
    GL = [a*ones(n2,1), yv'];
    GR = [b*ones(n2,1), yv'];
    GU = [yh', d*ones(n1,1)];
    GD = [yh', c*ones(n1,1)];

    % تولید نقاط داخلی
    switch dist_type
        case 'Halton'
            K = floor(((b-a)/h - 1) * ((d-c)/h - 1));
            HaltonPoints = Halton(K, a+h/2, b-h/2, c+h/2, d-h/2);
            Xi = HaltonPoints(:,1);
            Yi = HaltonPoints(:,2);
            Y = [Xi, Yi];
        case 'Uniform'
            [Xi, Yi] = meshgrid(yh', yv');
            Y = [Xi(:), Yi(:)];
    end

    % تعریف چند دایره کوچک به شعاع 0.1
    r_hole = 0.1;
    centers = [0.5, 0.5; 0.3, 0.7; 0.7, 0.3];  % مرکز دایره‌ها

    % حذف نقاطی که داخل دایره‌ها هستند
    inside_any_circle = false(size(Y,1),1);
    for i = 1:size(centers,1)
        dx = Y(:,1) - centers(i,1);
        dy = Y(:,2) - centers(i,2);
        r = sqrt(dx.^2 + dy.^2);
        inside_any_circle = inside_any_circle | (r < r_hole);
    end

    Y_filtered = Y(~inside_any_circle,:);

    % ذخیره نقاط داخلی و مرزی
    Points{1,1} = Y_filtered;
    Points{1,2} = 'Interior points';

    Points{2,1} = [GL; GR; GU; GD; a,c; b,c; a,d; b,d];
    Points{2,2} = 'Boundary points';

    case 00 % Rectangular domain
        yh=a+h:h:b-h;
        yv=c+h:h:d-h;
        n1=size(yh,2);
        n2=size(yv,2);
        GL=[a*ones(n2,1),yv'];
        GR=[b*ones(n2,1),yv'];
        GU=[yh',d*ones(n1,1)];
        GD=[yh',c*ones(n1,1)];
        switch dist_type
            case 'Halton'
                K  = floor(((b-a)/h-1)*((d-c)/h-1));
                HaltonPoints = Halton(K,a+h/2,b-h/2,c+h/2,d-h/2);
                Xi = HaltonPoints(:,1);
                Yi = HaltonPoints(:,2);
                Y = [Xi,Yi];
            case 'Uniform'
                [Xi,Yi]= meshgrid(yh',yv');
                Y=[Xi(:), Yi(:)];
        end
        Points{1,1} = [Y(:,1),Y(:,2)];
        Points{1,2} = 'Interior points';
        Points{2,1}=[GL;GR;GU;GD;a,c;b,c;a,d;b,d];
        Points{2,2} = 'Boundary points';
        
        
        
        
        case 1 % Rectangular domain with circular holes
    yh = a+h:h:b-h;
    yv = c+h:h:d-h;
    n1 = numel(yh);
    n2 = numel(yv);

    GL = [a*ones(n2,1), yv'];
    GR = [b*ones(n2,1), yv'];
    GU = [yh', d*ones(n1,1)];
    GD = [yh', c*ones(n1,1)];

    switch dist_type
        case 'Halton'
            K  = floor(((b-a)/h - 1)*((d-c)/h - 1));
            HaltonPoints = Halton(K, a+h/2, b-h/2, c+h/2, d-h/2);
            Xi = HaltonPoints(:,1);
            Yi = HaltonPoints(:,2);
            Y = [Xi, Yi];
        case 'Uniform'
            [Xi, Yi] = meshgrid(yh', yv');
            Y = [Xi(:), Yi(:)];
    end

    % ==== متخلخل کردن دامنه با چند دایره توخالی ====
    r_hole = 0.05;  % شعاع هر سوراخ
    num_x = 4;      % تعداد سوراخ در راستای x
    num_y = 4;      % تعداد سوراخ در راستای y

    % مراکز سوراخ‌ها به‌صورت منظم
    x_holes = linspace(a+0.15, b-0.15, num_x);
    y_holes = linspace(c+0.15, d-0.15, num_y);
    [HX, HY] = meshgrid(x_holes, y_holes);
    centers = [HX(:), HY(:)];

    % حذف نقاط داخلی که درون سوراخ‌ها هستند
    inside_hole = false(size(Y,1),1);
    for i = 1:size(centers,1)
        dx = Y(:,1) - centers(i,1);
        dy = Y(:,2) - centers(i,2);
        r = sqrt(dx.^2 + dy.^2);
        inside_hole = inside_hole | (r < r_hole);
    end

    Y_filtered = Y(~inside_hole,:);

    % ذخیره نقاط
    Points{1,1} = Y_filtered;
    Points{1,2} = 'Interior points';

    Points{2,1} = [GL; GR; GU; GD; a,c; b,c; a,d; b,d];
    Points{2,2} = 'Boundary points';

    case 7 % Rectangular domain with star-shaped holes
    yh = a+h:h:b-h;
    yv = c+h:h:d-h;
    n1 = numel(yh);
    n2 = numel(yv);

    GL = [a*ones(n2,1), yv'];
    GR = [b*ones(n2,1), yv'];
    GU = [yh', d*ones(n1,1)];
    GD = [yh', c*ones(n1,1)];

    switch dist_type
        case 'Halton'
            K  = floor(((b-a)/h - 1)*((d-c)/h - 1));
            HaltonPoints = Halton(K, a+h/2, b-h/2, c+h/2, d-h/2);
            Xi = HaltonPoints(:,1);
            Yi = HaltonPoints(:,2);
            Y = [Xi, Yi];
        case 'Uniform'
            [Xi, Yi] = meshgrid(yh', yv');
            Y = [Xi(:), Yi(:)];
    end

    % ==== تعریف حفره‌های ستاره‌ای شکل ====
    num_x = 3;          % تعداد سوراخ در جهت x
    num_y = 3;          % تعداد سوراخ در جهت y
    R0 = 0.05;          % شعاع پایه ستاره
    amp = 0.3;          % دامنه نوسان شعاع
    k = 5;              % تعداد پرهای ستاره

    x_holes = linspace(a+0.2, b-0.2, num_x);
    y_holes = linspace(c+0.2, d-0.2, num_y);
    [HX, HY] = meshgrid(x_holes, y_holes);
    centers = [HX(:), HY(:)];

    % حذف نقاط داخل حفره‌های ستاره‌ای
    inside_star = false(size(Y,1),1);
    for i = 1:size(centers,1)
        dx = Y(:,1) - centers(i,1);
        dy = Y(:,2) - centers(i,2);
        [theta, r] = cart2pol(dx, dy);
        r_star = R0 * (1 + amp * sin(k * theta));
        inside_star = inside_star | (r < r_star);
    end

    Y_filtered = Y(~inside_star,:);

    % ذخیره نقاط
    Points{1,1} = Y_filtered;
    Points{1,2} = 'Interior points';

    Points{2,1} = [GL; GR; GU; GD; a,c; b,c; a,d; b,d];
    Points{2,2} = 'Boundary points';
    
    case 2 % Eliptical domain
        switch dist_type
            case 'Halton'
                N  = floor(((b-a)/h)*((d-c)/h));
                HaltonPoints = Halton(N,-1,1,-1,1);
                X = HaltonPoints(:,1);
                Y = HaltonPoints(:,2);
                ind = X.^2+Y.^2<1-h/2;
                Xi = X(ind);
                Yi = Y(ind);
            case 'Uniform'
                N1 = ceil((b-a)/h);
                N2 = ceil((d-c)/h);
                yh=-1:2/N1:1;
                yv=-1:2/N2:1;
                [X, Y] = meshgrid(yh',yv');
                X = X(:);
                Y = Y(:);
                ind = X.^2+Y.^2<1-2/N1;
                Xi = X(ind);
                Yi = Y(ind);
        end
        Points{1,1} = [((b-a)/2)*Xi+(b+a)/2,((d-c)/2)*Yi+(d+c)/2];
        Points{1,2} = 'Interior points';
        Theta = (0:2/ceil((b-a)/h):2*pi)';
        Xi = ((b-a)/2).*cos(Theta)+(b+a)/2;
        Yi = ((d-c)/2).*sin(Theta)+(d+c)/2;
        Points{2,1} = [Xi,Yi];
        Points{2,2} = 'Boundary points';
    case 3 % Irregular Domain
        switch dist_type
            case 'Halton'
                N  = floor(((b-a)/h)*((d-c)/h));
                HaltonPoints = Halton(N,-1,1,-1,1);
                X = HaltonPoints(:,1);
                Y = HaltonPoints(:,2);
            case 'Uniform'
                N1 = ceil((b-a)/h);  N2 = ceil((d-c)/h);
                yh=-1:2/N1:1;
                yv=-1:2/N2:1;
                [X, Y] = meshgrid(yh',yv');
        end
        X = X(:);
        Y = Y(:);
        [Theta,R] = cart2pol(X,Y);
        R0 =(.55 + .25*(sin(6*Theta).^2+sin(6*Theta)));
        ind = R<R0-h/8;
        Xi = X(ind);
        Yi = Y(ind);
        Points{1,1} = [((b-a)/2)*Xi+(b+a)/2,((d-c)/2)*Yi+(d+c)/2];
        Points{1,2} = 'Interior points';
        Theta = (0:h:2*pi)';
        R = (.55 + .25*(sin(6*Theta).^2+sin(6*Theta)));
        Xi = ((b-a)/2)*R.*cos(Theta)+(b+a)/2;
        Yi = ((d-c)/2)*R.*sin(Theta)+(d+c)/2;
        Points{2,1} = [Xi,Yi];
        Points{2,2} = 'Boundary points';
   
     case 4 % Irregular Domain with Hollow Circle
    switch dist_type
        case 'Halton'
            N  = floor(((b-a)/h)*((d-c)/h));
            HaltonPoints = Halton(N,-1,1,-1,1);
            X = HaltonPoints(:,1);
            Y = HaltonPoints(:,2);
        case 'Uniform'
            N1 = ceil((b-a)/h);  N2 = ceil((d-c)/h);
            yh = -1:2/N1:1;
            yv = -1:2/N2:1;
            [X, Y] = meshgrid(yh', yv');
    end

    X = X(:);
    Y = Y(:);

    [Theta, R] = cart2pol(X, Y);
    R0 = 0.7 + 0.3*cos(4*Theta);  % مرز موج‌دار گل‌مانند
    r_hole = 0.25;         % شعاع دایره توخالی وسط

    % شرط برای نقاط داخلی: بین سوراخ و مرز خارجی
    ind = (R < R0 - h/8) & (R > r_hole);
    Xi = X(ind);
    Yi = Y(ind);

    Points{1,1} = [((b-a)/2)*Xi + (b+a)/2, ((d-c)/2)*Yi + (d+c)/2];
    Points{1,2} = 'Interior points';

    % مرز خارجی دامنه
    Theta = (0:h:2*pi)';
    R = 0.7 + 0.3*cos(4*Theta);
    Xi = ((b-a)/2)*R.*cos(Theta) + (b+a)/2;
    Yi = ((d-c)/2)*R.*sin(Theta) + (d+c)/2;
    Points{2,1} = [Xi, Yi];
    Points{2,2} = 'Boundary points';

    % مرز داخلی (دایره توخالی)
    r_in = r_hole;  % شعاع دایره داخلی
    Xi_hole = ((b-a)/2)*r_in*cos(Theta) + (b+a)/2;
    Yi_hole = ((d-c)/2)*r_in*sin(Theta) + (d+c)/2;
    Points{3,1} = [Xi_hole, Yi_hole];
    Points{3,2} = 'Inner hole boundary';

        case 5 % Irregular Domain - Flower-Like (4-petal)
    switch dist_type
        case 'Halton'
            N  = floor(((b-a)/h)*((d-c)/h));
            HaltonPoints = Halton(N,-1,1,-1,1);
            X = HaltonPoints(:,1);
            Y = HaltonPoints(:,2);
        case 'Uniform'
            N1 = ceil((b-a)/h);  N2 = ceil((d-c)/h);
            yh = -1:2/N1:1;
            yv = -1:2/N2:1;
            [X, Y] = meshgrid(yh', yv');
    end

    X = X(:); Y = Y(:);
    [Theta, R] = cart2pol(X, Y);
    
    R0 = 0.7 + 0.3*cos(4*Theta);  % شکل گل با ۴ پر
    ind = R < R0 - h/8;
    Xi = X(ind);
    Yi = Y(ind);
    
    Points{1,1} = [((b-a)/2)*Xi+(b+a)/2, ((d-c)/2)*Yi+(d+c)/2];
    Points{1,2} = 'Interior points';
    
    % مرز
    Theta = (0:h:2*pi)';
    R = 0.7 + 0.3*cos(4*Theta);
    Xi = ((b-a)/2)*R.*cos(Theta)+(b+a)/2;
    Yi = ((d-c)/2)*R.*sin(Theta)+(d+c)/2;
    
    Points{2,1} = [Xi, Yi];
    Points{2,2} = 'Boundary points';
        case 6 % Irregular Domain
        switch dist_type
            case 'Halton'
                N  = floor(((b-a)/h)*((d-c)/h));
                HaltonPoints = Halton(N,-1,1,-1,1);
                X = HaltonPoints(:,1);
                Y = HaltonPoints(:,2);
            case 'Uniform'
                N1 = ceil((b-a)/h);  N2 = ceil((d-c)/h);
                yh=-1:2/N1:1;
                yv=-1:2/N2:1;
                [X, Y] = meshgrid(yh',yv');
        end
        X = X(:);
        Y = Y(:);
        [Theta,R] = cart2pol(X,Y);
        R0 = 0.35 * (1 + 0.3*cos(6*Theta) + 0.2*sin(3*Theta)); 
        %R0 = 1 + sin(Theta);
        ind = R<R0-h/8;
        Xi = X(ind);
        Yi = Y(ind);
        Points{1,1} = [((b-a)/2)*Xi+(b+a)/2,((d-c)/2)*Yi+(d+c)/2];
        Points{1,2} = 'Interior points';
        Theta = (0:h:2*pi)';
        R = 0.35 * (1 + 0.3*cos(6*Theta) + 0.2*sin(3*Theta)); 
        %R = 1 + sin(Theta);
        Xi = ((b-a)/2)*R.*cos(Theta)+(b+a)/2;
        Yi = ((d-c)/2)*R.*sin(Theta)+(d+c)/2;
        Points{2,1} = [Xi,Yi];
        Points{2,2} = 'Boundary points';
end
function Points = Halton(N,a,b,c,e,d)
switch nargin
    case 0
        N = 1000;
        d = 2;
        a = 0; b = 1; c=0; e=0;
    case 1
        d = 2;
        a = 0; b = 1; c=0; e=1;
    case 5
        d=2;
end
p = haltonset(d,'Skip',1e3,'Leap',1e2);
X = net(p,N);
x=(b-a)*X(:,1)+a;
y=(c-e)*X(:,2)+e;
Points = [x,y];