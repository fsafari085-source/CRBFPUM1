function z = f( X,t )
%F Summary of this function goes here
%   Detailed explanation goes here
[d1,d2]=size(X);
x=X(:,1);
y=X(:,2);
if d2~=2
    disp('error in dimension in f(x)');
    return;
end
z=(sin(t) + exp(-t)) .* sin(pi*x) .* sin(pi*y);
%z = t.^3 .* (cos(2*pi*x) + cos(2*pi*y) - 2);
end